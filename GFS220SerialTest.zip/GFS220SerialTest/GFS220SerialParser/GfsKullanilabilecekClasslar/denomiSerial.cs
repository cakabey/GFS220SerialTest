﻿namespace GFS220SerialParser
{
    public class denomiSerial
    {
        public string denomi;
        public string serialNumber;
    }
}
