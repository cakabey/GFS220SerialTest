﻿using System;

namespace GFS220SerialParser
{
    public class denomiType
    {
        public string currency;
        private decimal denomi = 0;
        public decimal denomination
        {
            get { return denomi; }
            set
            {
                denomi = value;
                if (denomiCnt != 0)
                {
                    total = denomi * denomiCnt;
                }
            }
        }

        private decimal denomiCnt = 0;
        public decimal denomiCount
        {
            get { return denomiCnt; }
            set
            {
                denomiCnt = value;
                if (denomi != 0)
                {
                    total = denomi * denomiCnt;
                }
            }
        }

        private decimal total = 0;
        public decimal totalValue
        {
            get { return total; }
        }

        
    }
}
