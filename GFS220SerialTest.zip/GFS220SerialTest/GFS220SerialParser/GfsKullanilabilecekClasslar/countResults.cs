﻿using System.Collections.Generic;

namespace GFS220SerialParser
{
    public class countResults
    {
        public List<denomiType> denomiList = new List<denomiType>();
        public List<denomiSerial> serialList = new List<denomiSerial>();
    }
}
