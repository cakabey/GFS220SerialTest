﻿using System;

namespace GFS220SerialParser
{
    public static class Commons
    {
        public static string clearMessageString(String texttoclear)
        {
            texttoclear = texttoclear.Replace(Convert.ToChar(27).ToString(), "");
            texttoclear = texttoclear.Replace(Convert.ToChar(24).ToString(), "");
            texttoclear = texttoclear.Replace(Convert.ToChar(10).ToString(), "");
            texttoclear = texttoclear.Replace(Convert.ToChar(13).ToString(), "");
            texttoclear = texttoclear.Replace(Convert.ToChar(33).ToString(), "");
            return texttoclear;
        }
    }
}
