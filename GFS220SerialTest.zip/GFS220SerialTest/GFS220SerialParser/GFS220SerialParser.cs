﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GFS220SerialParser
{
    public class GFS220SerialParser
    {
        public List<denomiType> denomiList = new List<denomiType>();
        public List<denomiSerial> serialList = new List<denomiSerial>();
        public string currency;
        public countResults parseGFS220Message(string strMsg)
        {
            if (strMsg.IndexOf("<< Count Result >>") < 0 && strMsg.IndexOf("<< Grand Total >>") < 0 && strMsg.IndexOf(" Sonucu >>") < 0 && strMsg.IndexOf("<< Genel Toplam >>") < 0 && strMsg.IndexOf("<< Say?m Sonucu >>") < 0)
            {
                return new countResults();
            }

            string[] paraarray = strMsg.Split("\n".ToCharArray());

            for (int i = 0; i < paraarray.Length; i++)
            {
                paraarray[i] = Commons.clearMessageString(paraarray[i]);
            }

            //Date Time Process
            String line = paraarray[2];
            while (line.Contains("  "))
                line = line.Replace("  ", " ");

            //Currency Process
            line = paraarray[3].Replace(" ", "");
            currency = line.Substring(line.IndexOf(":") + 1).Trim();

            for (int i = 7; i < paraarray.Length; i++)
            {
                line = paraarray[i];

                while (line.Contains("  "))
                    line = line.Replace("  ", " ");

                if (String.IsNullOrEmpty(line))
                    continue;
                if (line.StartsWith("--"))
                    continue;
                if (line.Trim().StartsWith("DENOM"))
                    continue;
                if (line.Trim().StartsWith("TOTAL"))
                    continue;
                if (line.Trim().Contains("Serial"))
                    continue;
                if (line.Trim().Contains("Seri Numaras"))
                    continue;
                if (line.Contains(""))
                    continue;
                if (line.Trim().StartsWith("TOPLAM"))
                    continue;
                if (line.Trim().StartsWith("KUPšR"))
                    continue;

                if (line.Contains("Curr"))
                {
                    currency = line.Substring(line.IndexOf(":") + 1).Trim();
                    continue;
                }
                if (line.Contains("\u0005"))
                {
                    if (line.ToCharArray().Count(c => c == '\0')>1)
                    {
                        continue;
                    }
                    denomiSerial serial = new denomiSerial();
                    string[] cleartext = line.Replace("\0", "").Replace("\u0005", "").Split(' ');
                    serial.denomi = cleartext[2];
                    serial.serialNumber = cleartext[3];
                    serialList.Add(serial);
                    continue;
                }
                if (line.ToCharArray().Count(c => c == '\0') > 5)
                {
                    continue;
                }
                if (line.Contains("VB"))
                {
                    break;
                }

                denomiType denomi = new denomiType();
                if (line.StartsWith(" "))
                    line = line.Substring(1);
                denomi.denomination = decimal.Parse(line.Substring(0, line.IndexOf(" ")));
                denomi.denomiCount = decimal.Parse(line.Substring(line.IndexOf("(") + 1, line.IndexOf(")") - (line.IndexOf("(") + 1)).Trim());
                denomi.currency = currency;
                denomiList.Add(denomi);
            }
            countResults results = new countResults();
            results.denomiList = denomiList;
            results.serialList = serialList;
            return results;
        }
    }
}
