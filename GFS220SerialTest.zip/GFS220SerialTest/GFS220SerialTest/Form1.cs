﻿using GFS220SerialParser;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Threading;
using System.Windows.Forms;

namespace GFS220SerialTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            String[] portNames = SerialPort.GetPortNames();
            foreach (String portName in portNames)
            {
                portList.Items.Add(portName);
            }
            //string readedlines = "";
            //readedlines = File.ReadAllText(@"C:\Users\musta\OneDrive\Desktop\gfstest1.log");
            //GFS220SerialParser.GFS220SerialParser gfs = new GFS220SerialParser.GFS220SerialParser();
            //countResults result = gfs.parseGFS220Message(readedlines);
            //updateDenomiDatagrid(result.denomiList);
            //updateSerialDatagrid(result.serialList);
        }
        SerialPort serialPort;
        private void button1_Click(object sender, EventArgs e)
        {
            if (serialPort != null)
                if (serialPort.IsOpen)
                {
                    serialPort.DataReceived -= serialPort_DataReceived;
                    serialPort.Close();
                }
            
            if (string.IsNullOrEmpty(portList.SelectedItem.ToString()))
            {
                return;
            }
            serialPort = new SerialPort();
            serialPort.PortName = portList.SelectedItem.ToString();
            serialPort.BaudRate = 115200;
            serialPort.DataReceived += serialPort_DataReceived;
            serialPort.Open();
            Thread.Sleep(500);
            if (serialPort.IsOpen) {
                MessageBox.Show("Bağlandı");
            }
            else
                MessageBox.Show("Bağlantı sağlanamadı.");

        }

        /// <summary>
        /// Denomi gridi update etmek için kullanılır
        /// </summary>
        /// <param name="denomis">Denomi listesi</param>
        public void updateDenomiDatagrid(List<denomiType> denomis)
        {
            if (denomis == null)
            {
                return;
            }
            this.BeginInvoke((MethodInvoker)delegate ()
            {
                dataGridViewDenomi.Rows.Clear();
                foreach (var item in denomis)
                {
                    dataGridViewDenomi.Rows.Add(item.denomination, item.currency, item.denomiCount);
                }
            });
        }
        /// <summary>
        /// Serino gridi update etmek için kullanılır.
        /// </summary>
        /// <param name="denomiSerials">Serino Listesi</param>
        private void updateSerialDatagrid(List<denomiSerial> denomiSerials)
        {
            if (denomiSerials == null)
            {
                return;
            }
            this.BeginInvoke((MethodInvoker)delegate ()
            {
                dataGridViewSerial.Rows.Clear();
                foreach (var item in denomiSerials)
                {
                    dataGridViewSerial.Rows.Add(item.denomi, item.serialNumber);
                }
            });
        }

        void serialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                String message = "";
                while (serialPort.BytesToRead > 0)
                {
                    string tmpmsg = serialPort.ReadExisting();
                    message += tmpmsg;
                    Thread.Sleep(25);
                }
                GFS220SerialParser.GFS220SerialParser gfs = new GFS220SerialParser.GFS220SerialParser();
                countResults result = gfs.parseGFS220Message(message);
                updateDenomiDatagrid(result.denomiList);
                updateSerialDatagrid(result.serialList);
            }
            catch (Exception ex)
            {
                
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort != null)
            {
                if (serialPort.IsOpen)
                {
                    serialPort.DataReceived -= serialPort_DataReceived;
                    serialPort.Close();
                }
            }
        }
    }
}
