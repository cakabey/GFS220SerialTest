﻿namespace GFS220SerialTest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridViewDenomi = new System.Windows.Forms.DataGridView();
            this.dataGridViewSerial = new System.Windows.Forms.DataGridView();
            this.portList = new System.Windows.Forms.ComboBox();
            this.Denomi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Currency = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Count = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DenomiS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SerialNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDenomi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSerial)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(449, 137);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(160, 39);
            this.button1.TabIndex = 0;
            this.button1.Text = "Connect";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridViewDenomi
            // 
            this.dataGridViewDenomi.AllowUserToAddRows = false;
            this.dataGridViewDenomi.AllowUserToDeleteRows = false;
            this.dataGridViewDenomi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dataGridViewDenomi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDenomi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Denomi,
            this.Currency,
            this.Count});
            this.dataGridViewDenomi.Location = new System.Drawing.Point(12, 42);
            this.dataGridViewDenomi.Name = "dataGridViewDenomi";
            this.dataGridViewDenomi.ReadOnly = true;
            this.dataGridViewDenomi.RowHeadersVisible = false;
            this.dataGridViewDenomi.RowTemplate.Height = 24;
            this.dataGridViewDenomi.ShowEditingIcon = false;
            this.dataGridViewDenomi.ShowRowErrors = false;
            this.dataGridViewDenomi.Size = new System.Drawing.Size(401, 421);
            this.dataGridViewDenomi.TabIndex = 1;
            // 
            // dataGridViewSerial
            // 
            this.dataGridViewSerial.AllowUserToAddRows = false;
            this.dataGridViewSerial.AllowUserToDeleteRows = false;
            this.dataGridViewSerial.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewSerial.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSerial.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DenomiS,
            this.SerialNo});
            this.dataGridViewSerial.Location = new System.Drawing.Point(641, 42);
            this.dataGridViewSerial.Name = "dataGridViewSerial";
            this.dataGridViewSerial.ReadOnly = true;
            this.dataGridViewSerial.RowHeadersVisible = false;
            this.dataGridViewSerial.RowTemplate.Height = 24;
            this.dataGridViewSerial.ShowEditingIcon = false;
            this.dataGridViewSerial.ShowRowErrors = false;
            this.dataGridViewSerial.Size = new System.Drawing.Size(401, 421);
            this.dataGridViewSerial.TabIndex = 2;
            // 
            // portList
            // 
            this.portList.FormattingEnabled = true;
            this.portList.Location = new System.Drawing.Point(449, 91);
            this.portList.Name = "portList";
            this.portList.Size = new System.Drawing.Size(160, 24);
            this.portList.TabIndex = 3;
            // 
            // Denomi
            // 
            this.Denomi.FillWeight = 30F;
            this.Denomi.HeaderText = "Denomi";
            this.Denomi.MinimumWidth = 120;
            this.Denomi.Name = "Denomi";
            this.Denomi.ReadOnly = true;
            this.Denomi.Width = 120;
            // 
            // Currency
            // 
            this.Currency.FillWeight = 30F;
            this.Currency.HeaderText = "Currency";
            this.Currency.MinimumWidth = 120;
            this.Currency.Name = "Currency";
            this.Currency.ReadOnly = true;
            this.Currency.Width = 120;
            // 
            // Count
            // 
            this.Count.FillWeight = 40F;
            this.Count.HeaderText = "Count";
            this.Count.MinimumWidth = 138;
            this.Count.Name = "Count";
            this.Count.ReadOnly = true;
            this.Count.Width = 158;
            // 
            // DenomiS
            // 
            this.DenomiS.FillWeight = 50F;
            this.DenomiS.HeaderText = "Denomi";
            this.DenomiS.MinimumWidth = 100;
            this.DenomiS.Name = "DenomiS";
            this.DenomiS.ReadOnly = true;
            // 
            // SerialNo
            // 
            this.SerialNo.FillWeight = 50F;
            this.SerialNo.HeaderText = "Serial Number";
            this.SerialNo.MinimumWidth = 278;
            this.SerialNo.Name = "SerialNo";
            this.SerialNo.ReadOnly = true;
            this.SerialNo.Width = 298;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 30);
            this.label1.TabIndex = 4;
            this.label1.Text = "Denomi List";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(636, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 30);
            this.label2.TabIndex = 5;
            this.label2.Text = "Serial List";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe Print", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(444, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(165, 30);
            this.label3.TabIndex = 6;
            this.label3.Text = "Serial Connection";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(449, 204);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(160, 39);
            this.button2.TabIndex = 7;
            this.button2.Text = "Disconnect";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1054, 475);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.portList);
            this.Controls.Add(this.dataGridViewSerial);
            this.Controls.Add(this.dataGridViewDenomi);
            this.Controls.Add(this.button1);
            this.MinimumSize = new System.Drawing.Size(1072, 522);
            this.Name = "Form1";
            this.Text = "PROTEM - GFS220 Message Parsing";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDenomi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSerial)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridViewDenomi;
        private System.Windows.Forms.DataGridView dataGridViewSerial;
        private System.Windows.Forms.ComboBox portList;
        private System.Windows.Forms.DataGridViewTextBoxColumn Denomi;
        private System.Windows.Forms.DataGridViewTextBoxColumn Currency;
        private System.Windows.Forms.DataGridViewTextBoxColumn Count;
        private System.Windows.Forms.DataGridViewTextBoxColumn DenomiS;
        private System.Windows.Forms.DataGridViewTextBoxColumn SerialNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
    }
}

